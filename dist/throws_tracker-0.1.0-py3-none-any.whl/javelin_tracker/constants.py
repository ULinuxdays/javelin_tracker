"""Shared configuration defaults."""

DEFAULT_ATHLETE_PLACEHOLDER = "unassigned"
